package hr.algebra.benisapp

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.core.text.set
import androidx.fragment.app.Fragment
import hr.algebra.benisapp.databinding.ActivityMainBinding




class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var validationFileds: List<EditText>

    private class TestStatic {

        companion object {
            var i = 0;
            fun getValue(): Int {
                return i++;
            }


        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initValidation();
        setupListeners();


    }

    private fun initValidation() {


        validationFileds = listOf(
            binding.etKm
        )

    }

    private fun setupListeners() {
        binding.btnCalculate.setOnClickListener {
            if (formValid()) {
                var kmToSend = 0.0;
                if(binding.idBike.isChecked){var kmToSend = 0} else {kmToSend=binding.etKm.text.toString().toDouble()}
                val emCo2: Double? = calculate(kmToSend, 123.4)

                handleLyout(emCo2)
            }

        }

    }

    private fun formValid(): Boolean {
        validationFileds.forEach {
            if (it.text.toString().isBlank()) {
                it.error = getString(R.string.insert_mess)
                it.requestFocus()

                return false;
            }

            if(!binding.idBike.isChecked && !binding.idCar.isChecked){

                val builder = AlertDialog.Builder(this)
                builder.setTitle("Error")
                builder.setMessage(getString(R.string.choose_transport_alert))
                builder.show();
                return false

            }
        }
        return true;
    }


    private fun calculate(km: Double, emmision: Double): Double? {

        return if (km <= 0) {
            null
        } else {
            km * emmision
        }
    }

    private fun handleLyout(emCo2: Double?) {
            hideKeyboard()

        when {
            emCo2 == null -> {
                binding.tvResult.text = "0 g  CO2"
                binding.imResoult.setImageResource(R.drawable.happy)
            }

            emCo2 <= 150 -> {
                binding.tvResult.text = emCo2.toString()+ "g CO2"
                binding.imResoult.setImageResource(R.drawable.happy)
            }
            else ->{
                binding.tvResult.text = emCo2.toString()+ "g CO2"
                binding.imResoult.setImageResource(R.drawable.earthcrying)
            }
        }
    }
}
